create function pgr_maxflowpushrelabel(edges_sql text, source_vertex bigint, sink_vertex bigint, OUT seq integer, OUT edge_id bigint, OUT source bigint, OUT target bigint, OUT flow bigint, OUT residual_capacity bigint) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
        RETURN QUERY SELECT *
        FROM pgr_PushRelabel($1, $2, $3);
  END
$$;

comment on function pgr_maxflowpushrelabel(text, bigint, bigint, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) is 'pgr_maxFlowPushRelabel(Renamed function) use pgr_pushRelabel instead';

alter function pgr_maxflowpushrelabel(text, bigint, bigint, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) owner to postgres;

