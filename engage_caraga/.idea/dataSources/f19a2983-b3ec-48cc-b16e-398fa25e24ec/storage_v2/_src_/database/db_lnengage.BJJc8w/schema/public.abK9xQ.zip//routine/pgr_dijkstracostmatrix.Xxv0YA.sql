create function pgr_dijkstracostmatrix(edges_sql text, vids anyarray, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    RETURN query SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), $2, $2, $3, true) a;
END
$$;

alter function pgr_dijkstracostmatrix(text, anyarray, boolean, out bigint, out bigint, out double precision) owner to postgres;

