create function pgr_astar(edges_sql text, source_id integer, target_id integer, directed boolean, has_rcost boolean) returns SETOF pgr_costresult
    strict
    language plpgsql
as
$$
DECLARE
has_reverse BOOLEAN;
sql TEXT;
BEGIN
    RAISE NOTICE 'Deprecated signature pgr_astar(text, integer, integer, boolean, boolean)';
    has_reverse =_pgr_parameter_check('astar', edges_sql, false);
    sql = edges_sql;
    IF (has_reverse != has_rcost) THEN
        IF (has_reverse) THEN
            sql = 'SELECT id, source, target, cost, x1,y1, x2, y2 FROM (' || edges_sql || ') a';
        ELSE
            raise EXCEPTION 'has_rcost set to true but reverse_cost not found';
        END IF;
    END IF;

    RETURN query SELECT seq - 1 AS seq, node::INTEGER AS id1, edge::INTEGER AS id2, cost
    FROM pgr_astar(sql, ARRAY[$2], ARRAY[$3], directed);
END
$$;

comment on function pgr_astar(text, integer, integer, boolean, boolean) is 'pgr_astar(Deprecated signature)';

alter function pgr_astar(text, integer, integer, boolean, boolean) owner to postgres;

