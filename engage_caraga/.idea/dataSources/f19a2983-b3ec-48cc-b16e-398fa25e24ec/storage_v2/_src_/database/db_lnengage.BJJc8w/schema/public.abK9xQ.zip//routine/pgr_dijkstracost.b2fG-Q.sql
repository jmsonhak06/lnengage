create function pgr_dijkstracost(edges_sql text, start_vids anyarray, end_vids anyarray, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), $2::BIGINT[], $3::BIGINT[], $4, true) AS a;
$$;

comment on function pgr_dijkstracost(text, anyarray, anyarray, boolean, out bigint, out bigint, out double precision) is 'pgr_dijkstraCost(Many to Many)';

alter function pgr_dijkstracost(text, anyarray, anyarray, boolean, out bigint, out bigint, out double precision) owner to postgres;

