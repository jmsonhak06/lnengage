create function pgr_ksp(edges_sql text, start_vid bigint, end_vid bigint, k integer, directed boolean DEFAULT true, heap_paths boolean DEFAULT false, OUT seq integer, OUT path_id integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    language plpgsql
as
$$
DECLARE
  BEGIN
         RETURN query SELECT *
                FROM _pgr_ksp(edges_sql::text, start_vid, end_vid, k, directed, heap_paths);
  END
$$;

alter function pgr_ksp(text, bigint, bigint, integer, boolean, boolean, out integer, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

