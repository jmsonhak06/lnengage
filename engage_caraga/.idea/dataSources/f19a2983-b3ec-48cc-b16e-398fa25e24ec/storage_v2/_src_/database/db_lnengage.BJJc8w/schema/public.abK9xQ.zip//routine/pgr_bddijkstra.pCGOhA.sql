create function pgr_bddijkstra(edges_sql text, start_vid integer, end_vid integer, directed boolean, has_rcost boolean) returns SETOF pgr_costresult
    strict
    language plpgsql
as
$$
DECLARE
has_reverse BOOLEAN;
new_sql TEXT;
BEGIN
    RAISE NOTICE 'Deprecated Signature of pgr_bdDijkstra';
    has_reverse =_pgr_parameter_check('dijkstra', $1, false);
    new_sql = $1;
    IF (has_reverse != $5) THEN
        IF (has_reverse) THEN
            new_sql = 'SELECT id, source, target, cost FROM (' || $1 || ') a';
        ELSE
            raise EXCEPTION 'has_rcost set to true but reverse_cost not found';
        END IF;
    END IF;

    RETURN query SELECT seq-1 AS seq, node::integer AS id1, edge::integer AS id2, cost
    FROM _pgr_bdDijkstra(new_sql, ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], directed, false);
  END
$$;

comment on function pgr_bddijkstra(text, integer, integer, boolean, boolean) is 'pgr_bdDijkstra(Deprecated signature)';

alter function pgr_bddijkstra(text, integer, integer, boolean, boolean) owner to postgres;

