create function pgr_withpoints(edges_sql text, points_sql text, start_pid bigint, end_pid bigint, directed boolean DEFAULT true, driving_side character DEFAULT 'b'::bpchar, details boolean DEFAULT false, OUT seq integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.seq, a.path_seq, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_withPoints(_pgr_get_statement($1), $2, ARRAY[$3]::bigint[], ARRAY[$4]::bigint[], $5, $6, $7) AS a;
$$;

alter function pgr_withpoints(text, text, bigint, bigint, boolean, char, boolean, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

