create function "_pgr_unnest_matrix"(matrix double precision[], OUT start_vid integer, OUT end_vid integer, OUT agg_cost double precision) returns SETOF record
    strict
    cost 500
    rows 50
    language plpgsql
as
$$
DECLARE

m float8[];

BEGIN
    start_vid = 1;
    foreach m slice 1 in  ARRAY matrix
    LOOP
        end_vid = 1;
        foreach agg_cost in  ARRAY m
        LOOP
            RETURN next;
            end_vid = end_vid + 1;
        END LOOP;
        start_vid = start_vid + 1;
    END LOOP;
END;
$$;

alter function "_pgr_unnest_matrix"(double precision[], out integer, out integer, out double precision) owner to postgres;

