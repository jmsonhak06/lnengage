create function pgr_iscolumnintable(tab text, col text) returns boolean
    strict
    language plpgsql
as
$$
DECLARE
    cname text;
BEGIN
    raise notice 'pgr_isColumnInTable: This function will no longer be soported';
    select * from _pgr_getColumnName(tab,col,0, 'pgr_isColumnInTable') into cname;
    return  cname IS not NULL;
END;
$$;

comment on function pgr_iscolumnintable(text, text) is 'pgr_isColumnInTable(Deprecated function)';

alter function pgr_iscolumnintable(text, text) owner to postgres;

