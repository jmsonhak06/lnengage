create function st_setbandindex(rast raster, band integer, outdbindex integer, force boolean DEFAULT false) returns raster
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_SetBandPath($1, $2, NULL, $3, $4)
$$;

comment on function st_setbandindex(raster, integer, integer, boolean) is 'args: rast, band, outdbindex, force=false - Update the external band number of an out-db band';

alter function st_setbandindex(raster, integer, integer, boolean) owner to postgres;

