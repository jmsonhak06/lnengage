create function pgr_versionless(v1 text, v2 text) returns boolean
    strict
    language plpgsql
as
$$
BEGIN
    raise notice 'pgr_versionless: This function will no longer be soported';
    return  _pgr_versionless(v1,v2);
END;
$$;

comment on function pgr_versionless(text, text) is 'pgr_versionless(Deprecated function)';

alter function pgr_versionless(text, text) owner to postgres;

