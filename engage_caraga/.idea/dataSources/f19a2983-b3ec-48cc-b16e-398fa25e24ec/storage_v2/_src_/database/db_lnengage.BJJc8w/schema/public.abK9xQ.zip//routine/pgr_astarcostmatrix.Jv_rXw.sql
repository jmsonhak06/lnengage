create function pgr_astarcostmatrix(edges_sql text, vids anyarray, directed boolean DEFAULT true, heuristic integer DEFAULT 5, factor double precision DEFAULT 1.0, epsilon double precision DEFAULT 1.0, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    language plpgsql
as
$$
BEGIN
    RETURN query SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_astar(_pgr_get_statement($1), $2, $2, $3, $4, $5::FLOAT, $6::FLOAT, true) a;
END
$$;

alter function pgr_astarcostmatrix(text, anyarray, boolean, integer, double precision, double precision, out bigint, out bigint, out double precision) owner to postgres;

