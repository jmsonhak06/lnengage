create function pgr_texttopoints(pnts text, srid integer DEFAULT 4326) returns geometry[]
    immutable
    language plpgsql
as
$$
declare
    a text[];
    t text;
    p geometry;
    g geometry[];

begin
    RAISE NOTICE 'Deperecated function: pgr_textToPoints';
    -- convert commas to space and split on ';'
    a := string_to_array(replace(pnts, ',', ' '), ';');
    -- convert each 'x y' into a point geometry and concattenate into a new array
    for t in select unnest(a) loop
        p := st_pointfromtext('POINT(' || t || ')', srid);
        g := g || p;
    end loop;

    return g;
end;
$$;

comment on function pgr_texttopoints(text, integer) is 'pgr_texttopoints(Deprecated function)';

alter function pgr_texttopoints(text, integer) owner to postgres;

