create function pgr_maxflow(edges_sql text, source_vertices bigint, sink_vertices anyarray) returns bigint
    strict
    language sql
as
$$
SELECT *
        FROM pgr_maxflow($1, ARRAY[$2]::BIGINT[], $3::BIGINT[]);
$$;

alter function pgr_maxflow(text, bigint, anyarray) owner to postgres;

