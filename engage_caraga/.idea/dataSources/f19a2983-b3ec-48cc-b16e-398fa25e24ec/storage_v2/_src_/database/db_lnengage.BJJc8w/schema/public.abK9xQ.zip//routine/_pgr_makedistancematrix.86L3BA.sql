create function "_pgr_makedistancematrix"(sqlin text, OUT dmatrix double precision[], OUT ids integer[]) returns record
    stable
    cost 10
    language plpgsql
as
$$
declare
    sql text;
    r record;

begin
    dmatrix := array[]::double precision[];
    ids := array[]::integer[];

    sql := 'with nodes as (' || sqlin || ')
        select i, array_agg(dist) as arow from (
            select a.id as i, b.id as j, st_distance(st_makepoint(a.x, a.y), st_makepoint(b.x, b.y)) as dist
              from nodes a, nodes b
             order by a.id, b.id
           ) as foo group by i order by i';

    for r in execute sql loop
        dmatrix := array_cat(dmatrix, array[r.arow]);
        ids := ids || array[r.i];
    end loop;

end;
$$;

alter function "_pgr_makedistancematrix"(text, out double precision[], out integer[]) owner to postgres;

