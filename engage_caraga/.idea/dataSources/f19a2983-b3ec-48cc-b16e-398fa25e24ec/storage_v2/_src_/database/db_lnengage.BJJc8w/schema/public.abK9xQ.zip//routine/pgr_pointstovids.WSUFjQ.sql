create function pgr_pointstovids(pnts geometry[], edges text, tol double precision DEFAULT 0.01) returns integer[]
    stable
    language plpgsql
as
$$
declare
    v integer[];
    g geometry;

begin
    RAISE NOTICE 'Deperecated function: pgr_pointsToVids';
    -- cycle through each point and locate the nearest edge and vertex on that edge
    for g in select unnest(pnts) loop
        v := v || pgr_pointtoedgenode(edges, g, tol);
    end loop;

    return v;
end;
$$;

comment on function pgr_pointstovids(geometry[], text, double precision) is 'pgr_pointstovids(Deprecated function)';

alter function pgr_pointstovids(geometry[], text, double precision) owner to postgres;

