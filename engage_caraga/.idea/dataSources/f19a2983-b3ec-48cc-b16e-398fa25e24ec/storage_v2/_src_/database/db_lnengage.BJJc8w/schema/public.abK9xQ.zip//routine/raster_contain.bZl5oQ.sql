create function raster_contain(raster, raster) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$
select $1::geometry ~ $2::geometry
$$;

alter function raster_contain(raster, raster) owner to postgres;

