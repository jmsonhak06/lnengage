create function pgr_startpoint(g geometry) returns geometry
    immutable
    language plpgsql
as
$$
BEGIN
    raise notice 'pgr_startPoint: This function will no longer be soported';
    return  _pgr_startPoint(g);
END;
$$;

comment on function pgr_startpoint(geometry) is 'pgr_startPoint(Deprecated function)';

alter function pgr_startpoint(geometry) owner to postgres;

