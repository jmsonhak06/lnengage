create function pgr_quote_ident(idname text) returns text
    strict
    language plpgsql
as
$$
BEGIN
    raise notice 'pgr_isColumnInTable: This function will no longer be soported';
    return  _pgr_quote_ident(idname);
END;
$$;

comment on function pgr_quote_ident(text) is 'pgr_quote_ident(Deprecated function)';

alter function pgr_quote_ident(text) owner to postgres;

