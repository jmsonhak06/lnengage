create function pgr_maxflowedmondskarp(edges_sql text, source_vertices anyarray, sink_vertices anyarray, OUT seq integer, OUT edge_id bigint, OUT source bigint, OUT target bigint, OUT flow bigint, OUT residual_capacity bigint) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
        RETURN QUERY SELECT *
        FROM pgr_edmondsKarp($1, $2, $3);
  END
$$;

comment on function pgr_maxflowedmondskarp(text, anyarray, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) is 'pgr_maxFlowEdmondsKarp(Renamed function) use pgr_edmondsKarp instead';

alter function pgr_maxflowedmondskarp(text, anyarray, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) owner to postgres;

