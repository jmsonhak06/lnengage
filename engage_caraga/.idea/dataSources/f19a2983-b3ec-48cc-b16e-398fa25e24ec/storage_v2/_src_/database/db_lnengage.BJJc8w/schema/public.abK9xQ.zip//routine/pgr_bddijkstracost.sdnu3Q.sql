create function pgr_bddijkstracost(edges_sql text, bigint, bigint, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_bdDijkstra(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], $4, true) AS a;
$$;

alter function pgr_bddijkstracost(text, bigint, bigint, boolean, out bigint, out bigint, out double precision) owner to postgres;

