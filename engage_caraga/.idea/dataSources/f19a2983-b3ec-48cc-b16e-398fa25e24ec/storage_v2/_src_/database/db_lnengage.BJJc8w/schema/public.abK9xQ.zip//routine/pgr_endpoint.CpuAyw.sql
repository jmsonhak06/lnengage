create function pgr_endpoint(g geometry) returns geometry
    immutable
    language plpgsql
as
$$
BEGIN
    raise notice 'pgr_endPoint: This function will no longer be soported';
    return  _pgr_endPoint(g);
END;
$$;

comment on function pgr_endpoint(geometry) is 'pgr_endPoint(Deprecated function)';

alter function pgr_endpoint(geometry) owner to postgres;

