create function pgr_apspjohnson(edges_sql text) returns SETOF pgr_costresult
    strict
    language plpgsql
as
$$
DECLARE
  has_reverse boolean;
  sql TEXT;
  BEGIN
      RAISE NOTICE 'Deprecated function: Use pgr_johnson instead';
      has_reverse =_pgr_parameter_check('johnson', edges_sql, false);
      sql = edges_sql;
      IF (has_reverse) THEN
           RAISE NOTICE 'reverse_cost column found, removing.';
           sql = 'SELECT source, target, cost FROM (' || edges_sql || ') a';
      END IF;

      RETURN query
         SELECT (row_number() over () - 1)::integer as seq, start_vid::integer AS id1, end_vid::integer AS id2, agg_cost AS cost
         FROM  pgr_johnson(sql, TRUE);
  END
$$;

comment on function pgr_apspjohnson(text) is 'pgr_apspJohnson(Renamed function) use pgr_Johnson instead';

alter function pgr_apspjohnson(text) owner to postgres;

