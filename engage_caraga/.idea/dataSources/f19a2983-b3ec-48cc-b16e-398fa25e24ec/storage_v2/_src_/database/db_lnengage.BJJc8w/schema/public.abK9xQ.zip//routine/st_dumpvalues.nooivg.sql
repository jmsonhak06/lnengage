create function st_dumpvalues(rast raster, nband integer, exclude_nodata_value boolean DEFAULT true) returns double precision[]
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT valarray FROM public.ST_dumpvalues($1, ARRAY[$2]::integer[], $3)
$$;

comment on function st_dumpvalues(raster, integer, boolean) is 'args: rast, nband, exclude_nodata_value=true - Get the values of the specified band as a 2-dimension array.';

alter function st_dumpvalues(raster, integer, boolean) owner to postgres;

