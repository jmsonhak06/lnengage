create function pgr_bdastar(sql text, source_vid integer, target_vid integer, directed boolean, has_reverse_cost boolean) returns SETOF pgr_costresult
    strict
    language plpgsql
as
$$
DECLARE
has_reverse BOOLEAN;
new_sql TEXT;
BEGIN
    RAISE NOTICE 'Deprecated Signature of pgr_bdAstar';
    has_reverse =_pgr_parameter_check('astar', $1, false);
    new_sql = $1;
    IF (has_reverse != $5) THEN
        IF (has_reverse) THEN
            new_sql = 'SELECT id, source, target, cost FROM (' || $1 || ') a';
        ELSE
            raise EXCEPTION 'has_rcost set to true but reverse_cost not found';
        END IF;
    END IF;

    RETURN query SELECT seq-1 AS seq, node::integer AS id1, edge::integer AS id2, cost
    FROM _pgr_bdAstar(new_sql, ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], directed);
  END
$$;

comment on function pgr_bdastar(text, integer, integer, boolean, boolean) is 'pgr_bdAstar(Deprecated signature)';

alter function pgr_bdastar(text, integer, integer, boolean, boolean) owner to postgres;

