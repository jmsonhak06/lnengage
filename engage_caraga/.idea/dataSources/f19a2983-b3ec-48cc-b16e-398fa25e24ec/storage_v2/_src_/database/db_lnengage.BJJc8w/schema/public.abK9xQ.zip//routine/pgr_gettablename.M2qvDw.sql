create function pgr_gettablename(tab text, OUT sname text, OUT tname text) returns record
    strict
    language plpgsql
as
$$
BEGIN
    raise notice 'pgr_getTableName: This function will no longer be soported';
    select * from _pgr_getTableName(tab, 0, 'pgr_getTableName') into sname,tname;
END;
$$;

comment on function pgr_gettablename(text, out text, out text) is 'pgr_getTableName(Deprecated function)';

alter function pgr_gettablename(text, out text, out text) owner to postgres;

