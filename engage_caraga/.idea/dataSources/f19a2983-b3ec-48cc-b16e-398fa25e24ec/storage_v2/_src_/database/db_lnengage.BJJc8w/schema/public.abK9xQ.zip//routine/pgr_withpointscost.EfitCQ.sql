create function pgr_withpointscost(edges_sql text, points_sql text, start_pids anyarray, bigint, directed boolean DEFAULT true, driving_side character DEFAULT 'b'::bpchar, OUT start_pid bigint, OUT end_pid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.start_pid, $4, a.agg_cost
    FROM _pgr_withPoints(_pgr_get_statement($1), $2, $3::BIGINT[], ARRAY[$4]::BIGINT[], $5, $6, TRUE, TRUE) AS a;
$$;

alter function pgr_withpointscost(text, text, anyarray, bigint, boolean, char, out bigint, out bigint, out double precision) owner to postgres;

