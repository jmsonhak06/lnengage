create function pgr_bdastarcostmatrix(edges_sql text, vids anyarray, directed boolean DEFAULT true, heuristic integer DEFAULT 5, factor numeric DEFAULT 1.0, epsilon numeric DEFAULT 1.0, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    language sql
as
$$
SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_bdAstar(_pgr_get_statement($1), $2::BIGINT[], $2::BIGINT[], $3, $4, $5::FLOAT, $6::FLOAT, true) a;
$$;

comment on function pgr_bdastarcostmatrix(text, anyarray, boolean, integer, numeric, numeric, out bigint, out bigint, out double precision) is 'pgr_bdAstarCostMatrix';

alter function pgr_bdastarcostmatrix(text, anyarray, boolean, integer, numeric, numeric, out bigint, out bigint, out double precision) owner to postgres;

