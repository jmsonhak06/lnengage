create function pgr_dijkstra(edges_sql text, start_vid integer, end_vid integer, directed boolean, has_rcost boolean) returns SETOF pgr_costresult
    strict
    language plpgsql
as
$$
DECLARE
has_reverse BOOLEAN;
sql TEXT;
BEGIN
    RAISE NOTICE 'Deprecated function';
    has_reverse =_pgr_parameter_check('dijkstra', edges_sql, false);
    sql = edges_sql;
    IF (has_reverse != has_rcost) THEN
        IF (has_reverse) THEN
            sql = 'SELECT id, source, target, cost FROM (' || edges_sql || ') a';
        ELSE
            raise EXCEPTION 'has_rcost set to true but reverse_cost not found';
        END IF;
    END IF;

    RETURN query SELECT seq-1 AS seq, node::integer AS id1, edge::integer AS id2, cost
    FROM _pgr_dijkstra(sql, ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], directed, false);
  END
$$;

comment on function pgr_dijkstra(text, integer, integer, boolean, boolean) is 'pgr_dijkstra(Deprecated signature)';

alter function pgr_dijkstra(text, integer, integer, boolean, boolean) owner to postgres;

