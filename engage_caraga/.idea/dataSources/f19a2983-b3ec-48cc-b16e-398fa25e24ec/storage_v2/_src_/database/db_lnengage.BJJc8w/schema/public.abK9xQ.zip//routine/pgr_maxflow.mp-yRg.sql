create function pgr_maxflow(edges_sql text, source_vertices anyarray, sink_vertices anyarray) returns bigint
    strict
    language sql
as
$$
SELECT flow
        FROM _pgr_maxflow(_pgr_get_statement($1), $2::BIGINT[], $3::BIGINT[], algorithm := 1, only_flow := true);
$$;

alter function pgr_maxflow(text, anyarray, anyarray) owner to postgres;

