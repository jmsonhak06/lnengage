create function droprasterconstraints(rasttable name, rastcolumn name, VARIADIC constraints text[]) returns boolean
    strict
    language sql
as
$$
SELECT  public.DropRasterConstraints('', $1, $2, VARIADIC $3)
$$;

alter function droprasterconstraints(name, name, text[]) owner to postgres;

