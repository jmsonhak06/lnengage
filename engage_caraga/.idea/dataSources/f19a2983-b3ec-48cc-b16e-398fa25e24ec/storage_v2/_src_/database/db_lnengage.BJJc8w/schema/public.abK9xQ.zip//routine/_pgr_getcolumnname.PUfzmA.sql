create function "_pgr_getcolumnname"(sname text, tname text, col text, reporterrs integer DEFAULT 1, fnname text DEFAULT '_pgr_getColumnName'::text) returns text
    strict
    language plpgsql
as
$$
DECLARE
    cname text;
    naming record;
    err boolean;
BEGIN

    execute 'SELECT column_name FROM information_schema.columns
          WHERE table_name='||quote_literal(tname)||' and table_schema='||quote_literal(sname)||' and column_name='||quote_literal(col) into cname;

    IF cname is null  THEN
    execute 'SELECT column_name FROM information_schema.columns
          WHERE table_name='||quote_literal(tname)||' and table_schema='||quote_literal(sname)||' and column_name='||quote_literal(lower(col))  into cname;
    END if;

    err = cname is null;

    perform _pgr_onError(err, reportErrs, fnName,  'Column '|| col ||' not found', ' Check your column name','Column '|| col || ' found');
    RETURN cname;
END;
$$;

alter function "_pgr_getcolumnname"(text, text, text, integer, text) owner to postgres;

