create function pgr_pointstodmatrix(pnts geometry[], mode integer DEFAULT 0, OUT dmatrix double precision[], OUT ids integer[]) returns record
    stable
    language plpgsql
as
$$
declare
    r record;

begin
    RAISE NOTICE 'Deprecated function pgr_pointsToDMatrix';
    dmatrix := array[]::double precision[];
    ids := array[]::integer[];

    -- create an id for each point in the array and unnest it into a table nodes in the with clause
    for r in with nodes as (select row_number() over()::integer as id, p from (select unnest(pnts) as p) as foo)
        -- compute a row of distances
        select i, array_agg(dist) as arow from (
            select a.id as i, b.id as j,
                case when mode=0
                    then st_distance(a.p, b.p)
                    else st_distance_sphere(a.p, b.p)
                end as dist
              from nodes a, nodes b
             order by a.id, b.id
           ) as foo group by i order by i loop

        -- you must concat an array[array[]] to make dmatrix[][]
        -- concat the row of distances to the dmatrix
        dmatrix := array_cat(dmatrix, array[r.arow]);
        ids := ids || array[r.i];
    end loop;
end;
$$;

comment on function pgr_pointstodmatrix(geometry[], integer, out double precision[], out integer[]) is 'pgr_pointstodmatrix(Deprecated function)';

alter function pgr_pointstodmatrix(geometry[], integer, out double precision[], out integer[]) owner to postgres;

