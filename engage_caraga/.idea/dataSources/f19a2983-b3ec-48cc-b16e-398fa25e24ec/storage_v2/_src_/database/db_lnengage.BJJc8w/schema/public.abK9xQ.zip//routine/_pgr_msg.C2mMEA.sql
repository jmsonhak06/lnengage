create function "_pgr_msg"(msgkind integer, fnname text, msg text DEFAULT '---->OK'::text) returns void
    strict
    language plpgsql
as
$$
BEGIN
  if msgKind = 0 then
       raise debug '----> PGR DEBUG in %: %',fnName,msg;
  else
       raise notice '----> PGR NOTICE in %: %',fnName,msg;
  end if;
END;
$$;

alter function "_pgr_msg"(integer, text, text) owner to postgres;

