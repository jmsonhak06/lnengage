create function pgr_astar(edges_sql text, start_vid bigint, end_vid bigint, directed boolean DEFAULT true, heuristic integer DEFAULT 5, factor double precision DEFAULT 1.0, epsilon double precision DEFAULT 1.0, OUT seq integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.seq, a.path_seq, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_astar(_pgr_get_statement($1), ARRAY[$2]::BIGINT[],  ARRAY[$3]::BIGINT[], $4, $5, $6::FLOAT, $7::FLOAT) AS a;
$$;

comment on function pgr_astar(text, bigint, bigint, boolean, integer, double precision, double precision, out integer, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgr_astar(One to One)';

alter function pgr_astar(text, bigint, bigint, boolean, integer, double precision, double precision, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

