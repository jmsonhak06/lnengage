create function pgr_version()
    returns TABLE(version character varying, tag character varying, hash character varying, branch character varying, boost character varying)
    immutable
    language sql
as
$$
SELECT '2.6.2'::varchar AS version,
        'v2.6.2'::varchar AS tag,
        'b14f4d56b'::varchar AS hash,
        'master'::varchar AS branch,
        '1.59.0'::varchar AS boost;
$$;

alter function pgr_version() owner to postgres;

