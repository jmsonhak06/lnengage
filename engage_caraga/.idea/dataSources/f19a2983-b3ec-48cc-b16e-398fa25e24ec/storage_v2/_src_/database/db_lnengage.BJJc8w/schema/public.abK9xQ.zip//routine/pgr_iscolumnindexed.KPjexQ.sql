create function pgr_iscolumnindexed(tab text, col text) returns boolean
    strict
    language plpgsql
as
$$
BEGIN
    raise notice 'pgr_isColumnIndexed: This function will no longer be soported';
    return  _pgr_isColumnIndexed(tab,col);
END;
$$;

comment on function pgr_iscolumnindexed(text, text) is 'pgr_isColumnIndexed(Deprecated function)';

alter function pgr_iscolumnindexed(text, text) owner to postgres;

