create function st_within(rast1 raster, rast2 raster) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$
SELECT public.st_within($1, NULL::integer, $2, NULL::integer)
$$;

comment on function st_within(raster, raster) is 'args: rastA, rastB - Return true if no points of raster rastA lie in the exterior of raster rastB and at least one point of the interior of rastA lies in the interior of rastB.';

alter function st_within(raster, raster) owner to postgres;

