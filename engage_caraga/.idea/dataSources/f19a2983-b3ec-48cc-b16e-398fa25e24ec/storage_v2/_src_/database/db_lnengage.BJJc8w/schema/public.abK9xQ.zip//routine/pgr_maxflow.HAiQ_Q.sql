create function pgr_maxflow(edges_sql text, source_vertices anyarray, sink_vertices bigint) returns bigint
    strict
    language sql
as
$$
SELECT *
        FROM pgr_maxflow($1, $2::BIGINT[], ARRAY[$3]::BIGINT[]);
$$;

alter function pgr_maxflow(text, anyarray, bigint) owner to postgres;

