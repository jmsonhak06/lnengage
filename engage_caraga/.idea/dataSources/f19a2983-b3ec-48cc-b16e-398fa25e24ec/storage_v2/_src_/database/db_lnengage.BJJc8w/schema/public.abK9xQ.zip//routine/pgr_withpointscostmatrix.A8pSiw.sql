create function pgr_withpointscostmatrix(edges_sql text, points_sql text, pids anyarray, directed boolean DEFAULT true, driving_side character DEFAULT 'b'::bpchar, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    RETURN query SELECT a.start_pid, a.end_pid, a.agg_cost
        FROM _pgr_withPoints($1, $2, $3, $3, $4,  $5, TRUE, TRUE) AS a;
END
$$;

alter function pgr_withpointscostmatrix(text, text, anyarray, boolean, char, out bigint, out bigint, out double precision) owner to postgres;

