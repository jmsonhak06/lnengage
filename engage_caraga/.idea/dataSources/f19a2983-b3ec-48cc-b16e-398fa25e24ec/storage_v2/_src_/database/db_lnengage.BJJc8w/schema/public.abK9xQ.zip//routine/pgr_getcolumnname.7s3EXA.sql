create function pgr_getcolumnname(tab text, col text) returns text
    strict
    language plpgsql
as
$$
BEGIN
    raise notice 'pgr_getColumnName: This function will no longer be soported';
    return _pgr_getColumnName(tab,col, 0, 'pgr_getColumnName');
END;
$$;

comment on function pgr_getcolumnname(text, text) is 'pgr_getColumnName(Deprecated function)';

alter function pgr_getcolumnname(text, text) owner to postgres;

