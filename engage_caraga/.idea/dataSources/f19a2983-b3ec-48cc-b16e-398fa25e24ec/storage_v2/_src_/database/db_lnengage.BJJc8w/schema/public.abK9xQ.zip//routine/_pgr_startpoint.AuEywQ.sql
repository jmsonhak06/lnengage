create function "_pgr_startpoint"(g geometry) returns geometry
    immutable
    language plpgsql
as
$$
declare

begin
    if geometrytype(g) ~ '^MULTI' then
        return st_startpoint(st_geometryn(g,1));
    else
        return st_startpoint(g);
    end if;
end;
$$;

alter function "_pgr_startpoint"(geometry) owner to postgres;

