create function pgr_bddijkstracostmatrix(edges_sql text, vids anyarray, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    language sql
as
$$
SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_bdDijkstra(_pgr_get_statement($1), $2::BIGINT[], $2::BIGINT[], $3, true) a;
$$;

alter function pgr_bddijkstracostmatrix(text, anyarray, boolean, out bigint, out bigint, out double precision) owner to postgres;

