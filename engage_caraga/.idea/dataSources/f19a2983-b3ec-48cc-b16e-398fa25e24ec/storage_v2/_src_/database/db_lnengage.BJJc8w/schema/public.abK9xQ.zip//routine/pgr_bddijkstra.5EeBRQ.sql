create function pgr_bddijkstra(edges_sql text, start_vid bigint, end_vid bigint, directed boolean, OUT seq integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.seq, a.path_seq, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_bdDijkstra(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], $4, false) AS a;
$$;

alter function pgr_bddijkstra(text, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

