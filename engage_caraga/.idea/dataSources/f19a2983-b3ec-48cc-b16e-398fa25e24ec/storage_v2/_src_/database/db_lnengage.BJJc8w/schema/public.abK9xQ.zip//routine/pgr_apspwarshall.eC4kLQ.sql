create function pgr_apspwarshall(edges_sql text, directed boolean, has_rcost boolean) returns SETOF pgr_costresult
    strict
    language plpgsql
as
$$
DECLARE
  has_reverse boolean;
  sql TEXT;
  BEGIN
      RAISE NOTICE 'Deprecated function: Use pgr_floydWarshall instead';
      has_reverse =_pgr_parameter_check('dijkstra', edges_sql, false);
      sql := edges_sql;
      IF (has_reverse != has_rcost) THEN
         IF (has_reverse) THEN
           sql = 'SELECT id, source, target, cost FROM (' || edges_sql || ') a';
         ELSE raise EXCEPTION 'has_rcost set to true but reverse_cost not found';
         END IF;
      END IF;

      RETURN query
         SELECT (row_number() over () -1)::integer as seq, start_vid::integer AS id1, end_vid::integer AS id2, agg_cost AS cost
         FROM  pgr_floydWarshall(sql, directed);
  END
$$;

comment on function pgr_apspwarshall(text, boolean, boolean) is 'pgr_apspWarshall(Renamed function) use pgr_floydWarshall instead';

alter function pgr_apspwarshall(text, boolean, boolean) owner to postgres;

