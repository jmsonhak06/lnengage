create function postgis_sfcgal_scripts_installed() returns text
    immutable
    language sql
as
$$
SELECT '2.5.1'::text || ' r' || 17027::text AS version
$$;

alter function postgis_sfcgal_scripts_installed() owner to postgres;

