create function pgr_dijkstra(edges_sql text, start_vid bigint, end_vid bigint, directed boolean, OUT seq integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.seq, a.path_seq, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], directed, false, true) AS a;
$$;

comment on function pgr_dijkstra(text, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgr_dijkstra(One to One)';

alter function pgr_dijkstra(text, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

