create function pgr_maxflowboykovkolmogorov(edges_sql text, source_vertices anyarray, sink_vertices anyarray, OUT seq integer, OUT edge_id bigint, OUT source bigint, OUT target bigint, OUT flow bigint, OUT residual_capacity bigint) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
        RETURN QUERY SELECT *
        FROM pgr_boykovKolmogorov($1, $2, $3);
  END
$$;

comment on function pgr_maxflowboykovkolmogorov(text, anyarray, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) is 'pgr_maxFlowBoykovKolmogorov(Renamed function) use pgr_boykovKolmogorov instead';

alter function pgr_maxflowboykovkolmogorov(text, anyarray, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) owner to postgres;

