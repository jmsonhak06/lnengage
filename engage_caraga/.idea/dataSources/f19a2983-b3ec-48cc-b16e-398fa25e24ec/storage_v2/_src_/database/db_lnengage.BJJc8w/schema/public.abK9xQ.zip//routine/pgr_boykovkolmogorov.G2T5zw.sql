create function pgr_boykovkolmogorov(text, bigint, anyarray, OUT seq integer, OUT edge bigint, OUT start_vid bigint, OUT end_vid bigint, OUT flow bigint, OUT residual_capacity bigint) returns SETOF record
    strict
    language sql
as
$$
SELECT *
        FROM _pgr_maxflow(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], 2);
$$;

alter function pgr_boykovkolmogorov(text, bigint, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) owner to postgres;

