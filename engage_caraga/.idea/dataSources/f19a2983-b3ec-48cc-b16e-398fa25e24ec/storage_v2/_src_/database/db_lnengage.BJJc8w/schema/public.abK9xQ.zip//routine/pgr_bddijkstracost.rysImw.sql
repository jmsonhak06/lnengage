create function pgr_bddijkstracost(edges_sql text, bigint, end_vids anyarray, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_bdDijkstra(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], $4, true) as a;
$$;

alter function pgr_bddijkstracost(text, bigint, anyarray, boolean, out bigint, out bigint, out double precision) owner to postgres;

