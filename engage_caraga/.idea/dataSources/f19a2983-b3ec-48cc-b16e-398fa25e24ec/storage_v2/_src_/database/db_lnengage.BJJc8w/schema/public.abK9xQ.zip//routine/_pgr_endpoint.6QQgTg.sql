create function "_pgr_endpoint"(g geometry) returns geometry
    immutable
    language plpgsql
as
$$
declare

begin
    if geometrytype(g) ~ '^MULTI' then
        return st_endpoint(st_geometryn(g,1));
    else
        return st_endpoint(g);
    end if;
end;
$$;

alter function "_pgr_endpoint"(geometry) owner to postgres;

